import { useEffect, useRef, useState } from 'react';
import './App.css';

function App() {
  const [tooted, setTooted] = useState([]);
  const idRef = useRef();
  const nameRef = useRef();
  const priceRef = useRef();
  const isActiveRef = useRef();
  const [isUsd, setUsd] = useState(false);

  useEffect(() => {
    fetch("http://localhost:5249/Tooted")
        .then(res => res.json())
        .then(json => setTooted(json));
  }, []);

  function kustuta(index) {
    fetch("http://localhost:5249/Tooted/kustuta/" + index)
        .then(res => res.json())
        .then(json => setTooted(json));
  }

  function lisa() {
    fetch(`http://localhost:5249/Tooted/lisa/${Number(idRef.current.value)}/${nameRef.current.value}/${Number(priceRef.current.value)}/${isActiveRef.current.checked}`)
        .then(res => res.json())
        .then(json => setTooted(json));
  }

  function dollariteks() {
    const kurss = 1.1;
    setUsd(true);
    fetch("http://localhost:5249/Tooted/hind-dollaritesse/" + kurss)
        .then(res => res.json())
        .then(json => setTooted(json));
  }

  function eurodeks() {
    const kurss = 0.9091;
    setUsd(false);
    fetch("http://localhost:5249/Tooted/hind-dollaritesse/" + kurss)
        .then(res => res.json())
        .then(json => setTooted(json));
  }

  return (
      <div className="App">
        <label>ID</label> <br />
        <input ref={idRef} type="number" /> <br />
        <label>name</label> <br />
        <input ref={nameRef} type="text" /> <br />
        <label>price</label> <br />
        <input ref={priceRef} type="number" /> <br />
        <label>isActive</label> <br />
        <input ref={isActiveRef} type="checkbox" /> <br />
        <button onClick={() => lisa()}>Lisa</button>
        {tooted.map((toode, index) =>
            <div>
              <div>{toode.id}</div>
              <div>{toode.nimi}</div>
              <div>{toode.price.toFixed(2)}</div>
              <button onClick={() => kustuta(index)}>x</button>
            </div>)}
        {isUsd === false && <button onClick={() => dollariteks()}>Muuda dollariteks</button>}
        {isUsd === true && <button onClick={() => eurodeks()}>Muuda eurodeks</button>}
      </div>
  );
}

export default App;